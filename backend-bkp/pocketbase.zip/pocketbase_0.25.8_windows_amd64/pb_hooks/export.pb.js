/// <reference path="../pb_data/types.d.ts" />

// ./pocketbase export YOUR_COLLECTION data.json

$app.rootCmd.addCommand(new Command({
  use: "export",
  run: (cmd, args) => {
    const collectionIdOrName = args[0];
    const outputFile = args[1];

    // note: for simplicity this assume that the data can fit into memory;
    // if that's not the case then you can try loading it on batches
    // and perform a file write for each record (aka. 1 line write per record)
    const data = $app.findAllRecords(collectionIdOrName)

    $os.writeFile(outputFile, JSON.stringify(data), 0644);
  },
}))