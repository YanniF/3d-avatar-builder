/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_100374818")

  // add field
  collection.fields.addAt(6, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_794737568",
    "hidden": false,
    "id": "relation3626271845",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "cameraPlacement",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_100374818")

  // remove field
  collection.fields.removeById("relation3626271845")

  return app.save(collection)
})
